/workspaces/Lab2Sisop/buildroot-2025.02.16/modules/chardriver/chardriver.o
