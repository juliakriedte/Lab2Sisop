/workspaces/Lab2Sisop/buildroot-2025.02.16/modules/hello/hello.o
