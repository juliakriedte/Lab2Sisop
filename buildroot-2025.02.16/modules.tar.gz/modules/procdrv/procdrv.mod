/workspaces/Lab2Sisop/buildroot-2025.02.16/modules/procdrv/procdrv.o
